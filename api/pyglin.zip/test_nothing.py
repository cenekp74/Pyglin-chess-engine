import pytest


def test_nothing():
    assert True
