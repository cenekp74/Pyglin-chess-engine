if 0 == 0:
    print(1)
elif 0 == 1:
    print(2)
else:
    print(3)